package com.example.lenovo.octobertwelve;


import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Fragment03 extends Fragment {
    private LinearLayout ll_left;
    private TextView tv_left;
    private View v_left;
    private LinearLayout ll_right;
    private TextView tv_right;
    private View v_right;
    private ListView mListView;
    private List<String> list = new ArrayList<>();
    private MyAdapter myAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.item_layout3,container,false);
        initViews(view);
        for(int i = 0; i < 3; i++){
            list.add("");
        }
        myAdapter = new MyAdapter(getActivity(),list,R.layout.item_list);
        mListView.setAdapter(myAdapter);

        ll_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_left.setTextColor(Color.parseColor("#000000"));
                v_left.setVisibility(View.INVISIBLE);
                tv_right.setTextColor(Color.parseColor("#000000"));
                v_right.setVisibility(View.INVISIBLE);
                tv_left.setTextColor(Color.parseColor("#0C74F6"));
                v_left.setVisibility(View.VISIBLE);
            }
        });
        ll_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_left.setTextColor(Color.parseColor("#000000"));
                v_left.setVisibility(View.INVISIBLE);
                tv_right.setTextColor(Color.parseColor("#000000"));
                v_right.setVisibility(View.INVISIBLE);
                tv_right.setTextColor(Color.parseColor("#0C74F6"));
                v_right.setVisibility(View.VISIBLE);
            }
        });
        return view;
    }

    private void initViews(View view) {
        ll_left = (LinearLayout)view.findViewById(R.id.ll_left);
        tv_left = (TextView)view.findViewById(R.id.tv_left);
        v_left = (View)view.findViewById(R.id.v_left);
        ll_right = (LinearLayout)view.findViewById(R.id.ll_right);
        tv_right = (TextView)view.findViewById(R.id.tv_right);
        v_right = (View)view.findViewById(R.id.v_right);
        mListView = (ListView)view.findViewById(R.id.mListView);
    }
}
