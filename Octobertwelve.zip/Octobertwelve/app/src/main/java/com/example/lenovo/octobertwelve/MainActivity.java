package com.example.lenovo.octobertwelve;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout ll_wx;
    private ImageView iv_wx;
    private TextView tv_wx;
    private LinearLayout ll_txl;
    private ImageView iv_txl;
    private TextView tv_txl;
    private LinearLayout ll_fx;
    private ImageView iv_fx;
    private TextView tv_fx;
    private LinearLayout ll_w;
    private ImageView iv_w;
    private TextView tv_w;
    private ViewPager mViewPager;
    private TextView tv_title;
    private List<Fragment> fragments = new ArrayList<>();
    private InnerAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initData();

        adapter = new InnerAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(adapter);

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                setZT(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    private void setZT(int i) {
        iv_wx.setImageResource(R.drawable.fangzione);
        tv_wx.setTextColor(Color.parseColor("#000000"));
        iv_txl.setImageResource(R.drawable.shangdianone);
        tv_txl.setTextColor(Color.parseColor("#000000"));
        iv_fx.setImageResource(R.drawable.huodongone);
        tv_fx.setTextColor(Color.parseColor("#000000"));
        iv_w.setImageResource(R.drawable.woone);
        tv_w.setTextColor(Color.parseColor("#000000"));
        switch (i) {
            case 0:
                tv_title.setText("首页");
                iv_wx.setImageResource(R.drawable.fangzitwo);
                tv_wx.setTextColor(Color.parseColor("#D81E06"));
                break;
            case 1:
                tv_title.setText("市场");
                iv_txl.setImageResource(R.drawable.shangdiantwo);
                tv_txl.setTextColor(Color.parseColor("#D81E06"));
                break;
            case 2:
                tv_title.setText("活动投票");
                iv_fx.setImageResource(R.drawable.huodongtwo);
                tv_fx.setTextColor(Color.parseColor("#D81E06"));
                break;
            case 3:
                tv_title.setText("我的");
                iv_w.setImageResource(R.drawable.wotwo);
                tv_w.setTextColor(Color.parseColor("#D81E06"));
                break;
        }
    }

    private void initData() {
        fragments.add(new Fragment01());
        fragments.add(new Fragment02());
        fragments.add(new Fragment03());
        fragments.add(new Fragment04());
    }

    private void initViews() {
        ll_wx = (LinearLayout) findViewById(R.id.ll_wx);
        iv_wx = (ImageView) findViewById(R.id.iv_wx);
        tv_wx = (TextView) findViewById(R.id.tv_wx);
        ll_txl = (LinearLayout) findViewById(R.id.ll_txl);
        iv_txl = (ImageView) findViewById(R.id.iv_txl);
        tv_txl = (TextView) findViewById(R.id.tv_txl);
        ll_fx = (LinearLayout) findViewById(R.id.ll_fx);
        iv_fx = (ImageView) findViewById(R.id.iv_fx);
        tv_fx = (TextView) findViewById(R.id.tv_fx);
        ll_w = (LinearLayout) findViewById(R.id.ll_w);
        iv_w = (ImageView) findViewById(R.id.iv_w);
        tv_w = (TextView) findViewById(R.id.tv_w);
        mViewPager = (ViewPager) findViewById(R.id.mViewPager);
        tv_title = (TextView) findViewById(R.id.tv_title);

        ll_wx.setOnClickListener(this);
        ll_txl.setOnClickListener(this);
        ll_fx.setOnClickListener(this);
        ll_w.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ll_wx:
                setZT(0);
                mViewPager.setCurrentItem(0,false);
                break;
            case R.id.ll_txl:
                setZT(1);
                mViewPager.setCurrentItem(1,false);
                break;
            case R.id.ll_fx:
                setZT(2);
                mViewPager.setCurrentItem(2,false);
                break;
            case R.id.ll_w:
                setZT(3);
                mViewPager.setCurrentItem(3,false);
                break;

        }

    }
    class InnerAdapter extends FragmentPagerAdapter {
        public InnerAdapter(@NonNull FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }
    }
}
